<template>
	<div class="home-feature">
		<img src="~assets/images/home/recommend_bg.jpg" />
	</div>
</template>

<script>
	export default {
		name: 'HomeFeature'
	}
</script>

<style lang="less" scoped>
	.home-feature {
		img {
			width: 100%;
		}
	}
</style>
